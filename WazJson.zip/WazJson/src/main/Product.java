package main;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.util.Date;
import java.util.Set;

public class Product extends Entity<Product> {
    private String name;
    private Date releaseDate;
    private Person owner;
    private Set<Category> tags;

    public Product() {
        setProperties(new String[]{"name", "releaseDate", "owner", "tags"});
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public Person getOwner() {
        return owner;
    }

    public void setOwner(Person owner) {
        this.owner = owner;
    }

    public Set<Category> getTags() {
        return tags;
    }

    public void setTags(Set<Category> tags) {
        this.tags = tags;
    }

    @Override
    public String toString() {
        return "Product{" +
                "name='" + name + '\'' +
                ", releaseDate=" + releaseDate +
                ", owner=" + owner +
                ", tags=" + tags +
                '}';
    }

    @Override
    public String toJson(String... properties) {
        return "{" +
                UtilFormat.jsonFormatProperty(properties[0]) +  UtilFormat.propertyValueFormat(name) + ", " +
                UtilFormat.jsonFormatProperty(properties[1]) + UtilFormat.propertyValueFormat(releaseDate.toString()) + ", " +
                UtilFormat.jsonFormatProperty(properties[2]) + UtilFormat.jsonFormatObjectProperty(owner) + ", " +
                UtilFormat.jsonFormatProperty(properties[3]) + UtilFormat.jsonFormatArrayObjectProperty(tags) +
                "}";
    }

    @Override
    public String getPredicatValue(String predicat) {
        StringBuilder value = null;
        if(predicat.equals(getName())) {
            value = new StringBuilder(getName());
        } else if(predicat.equals(getReleaseDate())) {
            value = new StringBuilder((CharSequence) getReleaseDate());
        }  else if(predicat.equals(getOwner().getId())) {
            value = new StringBuilder(getOwner().getId());
        } else {
            for(Category tag : getTags()) {
                if(value.equals(tag.getName())) {
                    value = new StringBuilder(tag.getName());
                }
            }
        }

        if(value == null) {
            return null;
        }
        return value.toString();
    }

    @Override
    public Field[] getFields() {
        return this.getClass().getDeclaredFields();
    }

    @Override
    public Entity create(Field f) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchFieldException {
        if(this.getOwner().getClass().getTypeName().equals(f.getType().getTypeName())) {
            return new Person();
        } else {
            //Field ctags = UtilOutput.class.getDeclaredField("tags");
            ParameterizedType type = (ParameterizedType) f.getGenericType();
            Class<?> clazz = (Class<?>) type.getActualTypeArguments()[0];
            if(f.getName().equals("tags")) {
                return new Category();
            }
        }


        return null;
    }


}
