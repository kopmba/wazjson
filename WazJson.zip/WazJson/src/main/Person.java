package main;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.util.Set;

public class Person extends Entity<Person> {
    private int id;
    private String name;
    private Set<String> phones;

    public Person() {
        setProperties(new String[]{"id", "name", "phones"});
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<String> getPhones() {
        return phones;
    }

    public void setPhones(Set<String> phones) {
        this.phones = phones;
    }

    @Override
    public String toString() {
        return "Person{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", phones=" + phones +
                '}';
    }

    public String content() {
        return "{" +
                UtilFormat.jsonFormatProperty("id") +  id + ", " +
                UtilFormat.jsonFormatProperty("name")+ name + ", " +
                UtilFormat.jsonFormatProperty("name")+ name +
                "}";
    }

    @Override
    public String toJson(String... properties) {
        return "{" +
                UtilFormat.jsonFormatProperty(properties[0]) +  id + ", " +
                UtilFormat.jsonFormatProperty(properties[1]) + UtilFormat.propertyValueFormat(name) + ", " +
                UtilFormat.jsonFormatProperty(properties[2]) + UtilFormat.jsonFormatArrayProperty(phones) +
                "}";
    }

    @Override
    public String getPredicatValue(String predicat) {
        StringBuilder value = null;
        if(predicat.equals(getName())) {
            value = new StringBuilder(getName());
        } else if(predicat.equals(getId())) {
            value = new StringBuilder(getId());
        } else {
            for(String phone : getPhones()) {
                if(value.equals(phone)) {
                    value = new StringBuilder(phone);
                }
            }
        }

        if(value == null) {
            return null;
        }
        return value.toString();
    }

    @Override
    public Field[] getFields() {
        return this.getClass().getDeclaredFields();
    }

    @Override
    public Entity create(Field f) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Person p = (Person) f.getType().getConstructor(new Class[]{}).newInstance();
        return p;
    }

}
