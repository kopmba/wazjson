package main;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Type;
import java.util.*;

public class JsonObject {

    /**
     * This method compile json like : "prop1": {} or "prop2": : [{},{}] and required a converter
     * to implement
     * @param e
     * @param json
     * @return
     */
    public Map<String, Object> compile(Entity e, String json) throws NoSuchFieldException, InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        Map<String, Object> mapper = new HashMap<>();
        String keyPropFormat = "";
        for(int i = 0;  i < e.getFields().length; i++) {
            keyPropFormat = String.valueOf('"').concat(e.getFields()[i].getName()) + String.valueOf('"').concat(": ");
            int index = json.indexOf(keyPropFormat);
            if(index != -1) {
                int idx = index + keyPropFormat.length();
                String type = stringFromType(e.getFields()[i].getType());
                if(type.equals("array")) {
                    Map<String, Object> arrMap = new HashMap();
                    String str = (String) objectDataProperty(type, idx, json, "", e);
                    arrMap = compileString(e.create(e.getFields()[i]), str);
                    //next version retrieve properties from json file and add value in array
                    List<String> list = new ArrayList();
                    StringBuilder sb = new StringBuilder();
                    //push data in list
                    for(int j = 0; j < str.length(); j++) {
                        if(str.charAt(j) != '[') {
                            sb.append(str.charAt(j));
                            if((str.charAt(j) == '}' && str.charAt(j+1) == ','))  {
                                list.add(sb.toString());
                                sb = new StringBuilder();
                                continue;
                            }
                            if((str.charAt(j) == '}' && str.charAt(j+1) == ']'))  {
                                list.add(sb.toString());
                            }
                        }
                    }

                    List<Object> data = new ArrayList<>();
                    Map<String, Object> objMap = new HashMap();
                    //build object from json
                    for(String jsonstr : list) {
                        objMap = compileString(e.create(e.getClass().getDeclaredField(e.getFields()[i].getName())), jsonstr);
                        data.add(objMap);
                    }
                    mapper.put(e.getFields()[i].getName(), data);
                }

                else if(type.equals("object")) {
                   Map<String, Object> objMap = new HashMap();
                   if(i < e.getFields().length - 1) {
                       String keyProp = String.valueOf('"').concat(e.getFields()[i+1].getName()) + String.valueOf('"').concat(": ");
                       String str = (String) objectDataProperty(type, idx, json, keyProp, e);
                       objMap = compileString(e.create(e.getFields()[i]), str);
                       mapper.put(e.getFields()[i].getName(), objMap);
                    }
                } else {
                    mapper.put(e.getFields()[i].getName(), objectDataProperty(type, idx, json, "", e));
                }
            }
        }
        return mapper;
    }

    /**
     * This method compile json like : "prop" : [1, 2] where {} become a value number, boolean or string
     * @param e
     * @param json
     * @return
     */
    public Map<String, Object> compileString(Entity e, String json) {
        Map<String, Object> mapper = new HashMap<>();
        String keyPropFormat = "";
        for(int i = 0;  i < e.getFields().length; i++) {
            keyPropFormat = String.valueOf('"').concat(e.getFields()[i].getName()) + String.valueOf('"').concat(": ");
            int index = json.indexOf(keyPropFormat);
            if(index != -1) {
                int idx = index + keyPropFormat.length();
                String type = stringFromType(e.getFields()[i].getType());
                if(type.equals("array")) {
                    String str = (String) objectDataProperty(type, idx, json, "", e);
                    List<String> arr = new ArrayList<>();
                    StringBuilder bder = new StringBuilder();
                    for (int j = 0; j < str.length(); j++) {
                        if (str.charAt(j) != '"' && str.charAt(j) != '[') {
                            if (str.charAt(j) == ',' || str.charAt(j) == ']') {
                                arr.add(bder.toString());
                                bder = new StringBuilder();
                                continue;
                            }
                            bder.append(str.charAt(j));
                        }

                    }
                    mapper.put(e.getFields()[i].getName(), arr);
                } else if(type.equals("object")) {
                    //retrieve values properties from json data and convert define usingclass utility
                } else {
                    mapper.put(e.getFields()[i].getName(), objectDataProperty(type, idx, json, "", e));
                }
            }
        }
        return mapper;
    }

    public Map<String, Object> compileStringFromArray() {
        return null;
    }

    public Map<String, Object> compileStringObject(Entity e, String json) {
        Map<String, Object> mapper = new HashMap<>();
        String keyPropFormat = "";
        for(int i = 0;  i < e.getFields().length; i++) {
            keyPropFormat = String.valueOf('"').concat(e.getFields()[i].getName()) + String.valueOf('"').concat(": ");
            int index = json.indexOf(keyPropFormat);
            if(index != -1) {
                int idx = index + keyPropFormat.length();
                String type = stringFromType(e.getFields()[i].getType());
                if(type.equals("array")) {
                    String str = (String) objectDataProperty(type, idx, json, "", e);
                    List<String> arr = new ArrayList<>();
                    StringBuilder bder = new StringBuilder();
                    for (int j = 0; j < str.length(); j++) {
                        if (str.charAt(j) != '"' && str.charAt(j) != '[') {
                            if (str.charAt(j) == ',' || str.charAt(j) == ']') {
                                arr.add(bder.toString());
                                bder = new StringBuilder();
                                continue;
                            }
                            bder.append(str.charAt(j));
                        }

                    }
                    mapper.put(e.getFields()[i].getName(), arr);
                } else if(type.equals("object")) {
                    //retrieve values properties from json data and convert define usingclass utility
                } else {
                    mapper.put(e.getFields()[i].getName(), objectDataProperty(type, idx, json, "", e));
                }
            }
        }
        return mapper;
    }

    /**
     * Transform map of object to that object
     * @param e
     * @param map
     * @return
     */
    public Object convert(Entity e, Map<String, Object> map) {
        //to implement next version
        return null;
    }

    public String stringFromType(Type type) {
        String str = "";
        if(type.getTypeName().equals("java.util.Set")) {
            str = "array";
        }  else if(type.getTypeName().equals("java.lang.Boolean")) {
            str = "boolean";
        } else if(type.getTypeName().equals("java.lang.String") || type.getTypeName().equals("java.util.Date")) {
            str = "string";
        } else if(type.getTypeName().equals("int") || type.getTypeName().equals("long") || type.getTypeName().equals("double")) {
            str = "number";
        } else {
            str = "object";
        }
        return str;
    }

    public Object objectDataProperty(String type, int index, String json, String keyprop, Entity e) {
        if (type.equals("string")) {
            return UtilOutput.retrieveDataString(json.substring(index));
        } else if (type.equals("number")) {
            return UtilOutput.retrieveDataNumber(json.substring(index));
        } else if (type.equals("object")) {
            return UtilOutput.retrieveJsonObjectString(json.substring(index), keyprop);
        } else if (type.equals("array")) {
            return UtilOutput.retrieveJsonArrayString(json.substring(index), e);
        } else {
            return UtilOutput.retrieveDataBoolean(json.substring(index));
        }
    }

}
