package main;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

public abstract class Entity<T> {

    protected String[] properties;
    public abstract String toJson(String ...properties);
    public abstract String getPredicatValue(String predicat);

    public abstract Field[] getFields();

    public abstract Entity create(Field f) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchFieldException;
    public String[] getProperties() {
        return properties;
    }
    public void setProperties(String[] properties) {
        this.properties = properties;
    }


}
