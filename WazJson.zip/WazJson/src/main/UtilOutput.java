package main;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.List;

public class UtilOutput {

    public static String retrieveDataString(String json) {
        StringBuilder value = new StringBuilder();
        for(int i = 0; i < json.length(); i++) {
            if(json.charAt(i) != '"') {
                value.append(json.charAt(i));
            }
            if((json.charAt(i) == '"' && json.charAt(i+1) == ',') || (json.charAt(i) == '"'  && json.charAt(i+1) == '}')) {
                return value.toString();
            }
        }
        return "";
    }

    public static Object retrieveDataObject(String json) {
        return null;
    }

    public static String retrieveDataBoolean(String json) {
        StringBuilder value = new StringBuilder();
        for(int i = 0; i < json.length(); i++) {
            if(json.charAt(i) == 'f') {
                value.append("false");
            }
            if(json.charAt(i) == 't') {
                value.append("true");
            }
            if(json.charAt(i) == ',' && json.charAt(i-1) == 'e') {
                return value.toString();
            }
        }
        return "";
    }

    public static String retrieveDataNumber(String json) {
        StringBuilder value = new StringBuilder();
        for(int i = 0; i < json.length(); i++) {
            if(json.charAt(i) == ',') {
                return value.toString();
            }
            value.append(json.charAt(i));

        }
        return null;
    }

    public static Object[] retrieveDataArray(String json) {
        return null;
    }

    public static String retrieveJsonString(String json) {
        StringBuilder value = new StringBuilder();
        for(int i = 0; i < json.length(); i++) {
            value.append(json.charAt(i));
            boolean cond1 =  json.charAt(i) == ']';
            if(cond1) {
                return value.toString();
            }
        }
        return null;
    }

    public static String retrieveJsonObjectString(String json, String keyprop) {
        StringBuilder value = new StringBuilder();
        for(int i = 0; i < json.length(); i++) {
            value.append(json.charAt(i));
            boolean cond1 = json.charAt(i) == '}' && json.charAt(i-1) == ']';
            int index = json.indexOf(keyprop);
            boolean cond2 = json.charAt(i) == '}' && json.indexOf(i+2) == index;
            if(cond1 || cond2) {
                return value.toString();
            }
        }
        return null;
    }

    public static String retrieveJsonArrayString(String json, Entity e) {
        StringBuilder value = new StringBuilder();
        for(int i = 0; i < json.length(); i++) {
            value.append(json.charAt(i));
            boolean cond1 = json.charAt(i) == ']';
            if(cond1) {
                ArrayList list = new ArrayList();
                return value.toString();
            }
        }
        return null;
    }

    public static String[] propertiesFromJson(String json) {
        String valStr = "{" + String.valueOf('"') + "name" + String.valueOf('"') + ": " + String.valueOf('"') + "love" + String.valueOf('"') + "}";
        String valNum = "{" + String.valueOf('"') + "id" + String.valueOf('"') + ": " + "1" + "}";
        String valArray = "[" + "1324" + ", " + "42627" + "]";
        return null;
    }

    public static void main(String[] args) throws NoSuchFieldException {
        String val = String.valueOf('"') + "name" + String.valueOf('"') + ": " + String.valueOf('"') + "love" + String.valueOf('"') + ",";
        System.out.println(val + "\n");
        int starti = val.indexOf(String.valueOf('"').concat(":"));
        System.out.println(starti + "\n");
        int index = val.length() - 1;
        System.out.println(val.charAt(index) + "\n");
        StringBuilder output = new StringBuilder();
        for(index = val.length() -2 ; index > starti + 2 ; index-- ) {
            if(val.charAt(index) != '"') {
                output.append(val.charAt(index));
            }
        }
        System.out.println("The value is : " + output.reverse() + "\n");
        StringBuilder output1 = new StringBuilder();
        System.out.println("Retrieve the property \n");
        /*for(int i = 0 ; index > starti ; i++ ) {
            if(val.charAt(index) != '"') {
                output1.append(val.charAt(index));
            }
        }
        System.out.println("The value is : " + output1 + "\n");*/

        List<Category> list = new ArrayList<Category>();
        Field clist = UtilOutput.class.getDeclaredField("list");
        ParameterizedType type = (ParameterizedType) clist.getGenericType();
        Class<?> clazz = (Class<?>) type.getActualTypeArguments()[0];
        System.out.println("The value generic : " + list.getClass().getGenericSuperclass() + "\n");
    }
}
